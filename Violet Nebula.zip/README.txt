To install the included resource pack:
Just navigate to NEW SCUFFED BHOP SIMULATOR in your Steam folder: [C:\Program Files (x86)\Steam\steamapps\common\NEW EPIC SCUFFED BHOP SIMULATOR 2023 (POG CHAMP)].
Then drop the included file into bhop_Data!
After that just start your game and you should be good to go!
I've also included the default file, so if you want to go back to the default skin just do the exact same process, but with the file that's in the folder "default".
Hope you enjoy the pack!

-Bone4Crusher
